## test/verilog 文件夹

本文件夹放置 verilog 仿真文件，这些仿真文件可以在**Vivado波形仿真环境**下运行。
从而验证 verilog 硬件设计的正确性。

### 测试项目

### 测试状态