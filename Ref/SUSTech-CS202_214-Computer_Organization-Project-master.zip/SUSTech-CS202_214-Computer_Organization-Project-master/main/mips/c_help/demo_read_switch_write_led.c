/**
 * 编程场景
 * 输入：0x72(8位) 0x70(16位) 
 * 输出: 0x62(8位)  0x60(16位) 
 * 允许使用mips32中非乘除、非浮点数、非异常指令。
 */
int* stdin_left = 0x72;
int* stdin_right = 0x70;
int* stdout_left = 0x62;
int* stdout_right = 0x60;
int main(){
    
    return 0;
}