# SUSTech CS202/214 Computer Organization Project

[![](https://img.shields.io/badge/English-%E4%B8%AD%E6%96%87-green.svg)](README.md)[![](https://img.shields.io/badge/License-MulanPSL%202.0-green.svg)](LICENSE)[![](https://img.shields.io/badge/Chat-on%20QQ-green.svg?logo=tencentqq)](https://jq.qq.com/?_wv=1027&k=d02UjNgH)

This is a big assignment of cs202 / 214 computer organization course of Southern University of science and technology，which is to realize a CPU.

The basic function of this project is to realize a single cycle CPU supporting MIPS instruction set based on FPGA and Verilog language.

## Building from Source

## How to contribute

